SKIPUNZIP=1
URL="https://github.com/HuskyDG/revanced-build-ci/releases/download/latest/revanced-magisk-base.zip"

ABI=$(getprop ro.product.cpu.abi)
  if [ "$ABI" = "x86" ]; then
    ARCH=x86
    ABI32=x86
    IS64BIT=false
  elif [ "$ABI" = "arm64-v8a" ]; then
    ARCH=arm64
    ABI32=armeabi-v7a
    IS64BIT=true
  elif [ "$ABI" = "x86_64" ]; then
    ARCH=x64
    ABI32=x86
    IS64BIT=true
  else
    ABI=armeabi-v7a
    ARCH=arm
    ABI32=armeabi-v7a
    IS64BIT=false
  fi

if [ "$ABI" == "arm64-v8a" ]; then
    short_ABI=arm64
    ABI_APK=arm64_v8a
elif [ "$ABI" == "armeabi-v7a" ]; then
    short_ABI=arm
    ABI_APK=armeabi_v7a
else
    short_ABI="$ABI"
    ABI_APK="$ABI"
fi

URL_ABI="https://github.com/HuskyDG/revanced-build-ci/releases/download/latest/revanced-magisk-${ABI_APK}.zip"

# stub module installer

ui_print "- Download module, please be patient"
ping -c 1 google.com &>/dev/null || abort "! No internet connection"
wget "$URL" -O "$TMPDIR/revanced-magisk.zip" || abort "! Download failed"

ui_print "- Extracting module files"
unzip -o "$TMPDIR/revanced-magisk.zip" -x customize.sh -d "$MODPATH" &>/dev/null
mkdir -p "$TMPDIR/installer"
unzip -o "$TMPDIR/revanced-magisk.zip" customize.sh -d "$TMPDIR/installer" &>/dev/null
ui_print "- YouTube version: $(grep_prop version "$MODPATH/module.prop")"
. "$TMPDIR/installer/customize.sh"